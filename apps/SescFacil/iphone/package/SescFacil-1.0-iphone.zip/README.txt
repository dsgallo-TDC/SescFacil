This folder contains an iOS project based on a Worklight template project.   
The contents of this project are:
* Classes       - Project classes
* NativeSDK     - Objective-C API classes for accessing the Worklight server
* Plugins       - Worklight specific Cordova plugins
* www           - Contains the html, css and javascript sources for the project (including the javascript API for accessing the Worklight server).   
